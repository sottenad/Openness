## Microsoft Openness
http://www.microsoft.com/en-us/openness/default.aspx#home


We are using the following technologies to replace the old silverlight player:
* http://videojs.com/

Existing Technology (also consult /js/includes.js):
* modernizr
* html5shiv
* bigCarousel
* jquery hashchange event - Ben Alman
* Pretty Date - John Resig
* jquery easing
* jScrollPane - Kelvin Luck
* jCarousel - Jan Sorgalla
* jQuery Scroll - Brandon Aaron

========
